# Kiokio Pro — мод на базе Telegram-Android

Приватный клиент в терминальной эстетике. Не инструмент атаки — инструмент контроля собственных следов.

## КРАСНАЯ ЛИНИЯ ПРОЕКТА

Автор мода принципиально против доксинга. В мод не включены и не будут включены:
пробив по номеру/нику, определение чужих IP и геолокации, анти-ревоки,
IP-грабберы, брутфорс, обход защит, юзерботы-рассылки.
Любой PR, добавляющий такие функции, отклоняется без обсуждения.

## Состав

```
TMessagesProj/src/main/java/tw/kiokio/
├── core/
│   ├── ProCode.java                  # секретный код хранится ТОЛЬКО как SHA-256
│   └── KiokioConfig.java             # локальный конфиг ghosttalk_config.json
├── settings/
│   ├── Disclaimer.java               # дисклеймер внизу каждого экрана
│   ├── GhostSettingsActivity.java    # меню Kiokio (обычная настройка мода)
│   └── KiokioProGateActivity.java    # вход в Pro по коду
└── pro/
    ├── KiokioProActivity.java        # специальное меню Pro
    ├── SelfAuditActivity.java        # «След»: кнопка «Проверить меня»
    └── SelfAuditRunner.java          # конвейер проверки (только свой аккаунт)
```

## Установка в форк Telegram-Android

1. Скопируй папку `TMessagesProj` из архива поверх корня своего форка —
   файлы лягут в правильные пути. Манифест правится вручную: см. MANIFEST_PATCH.txt.
2. Код доступа к Kiokio Pro сейчас — **1991** (хэш уже вписан в ProCode.java).
   Свой код: `echo -n "ТВОЙ_КОД" | sha256sum` → замени константу CODE_SHA256.
3. В TMessagesProj/build.gradle укажи свой applicationId
   (НЕ org.telegram.messenger — иначе APK не установится рядом с официальным).
4. Сборка: локально в Android Studio или через GitHub Actions
   (workflow уже в архиве: .github/workflows/build.yml).
5. Скачай APK из артефактов Actions и установи на телефон
   («установка из неизвестных источников»).

## Сборка локально

```
git clone https://github.com/ТВОЙ_НИК/Telegram
# скопировать файлы из архива в корень репозитория
cd Telegram/TMessagesProj
../gradlew assembleDebug        # APK: TMessagesProj/build/outputs/apk/debug/
```

## Важно

- Отчёт «След» живёт только в памяти экрана, в БД не пишется.
- Точки вживления Telegram API отмечены TODO в SelfAuditRunner.java.
- Panic-вайп стирает конфиг и весь раздел Kiokio.
