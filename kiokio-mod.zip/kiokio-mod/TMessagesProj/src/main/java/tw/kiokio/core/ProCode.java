package tw.kiokio.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Секретный код Kiokio Pro.
 * Код доступа хранится ТОЛЬКО как SHA-256, сам код в исходниках не лежит.
 * Текущий код: 1991 (хэш вписан). Свою пару сгенерируй:
 *   echo -n "ТВОЙ_КОД" | sha256sum
 */
public final class ProCode {

    public static final String CODE_SHA256 =
            "8e9b669109df89620b94f2387dc53206a82ddc71d658f8f7a2b3a9b417370d3e";

    /** Проверка ввода. Не логирует, ничего не сохраняет. */
    public static boolean check(String input) {
        if (input == null || input.isEmpty()) return false;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(input.trim().getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            return sb.toString().equals(CODE_SHA256);
        } catch (Exception e) {
            return false;
        }
    }

    private ProCode() {}
}
