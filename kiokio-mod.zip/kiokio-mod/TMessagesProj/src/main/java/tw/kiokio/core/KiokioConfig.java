package tw.kiokio.core;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Локальный конфиг мода: ghosttalk_config.json в приватной папке приложения.
 * «Легальная замена правки кода»: настройки меняют поведение без пересборки.
 * При panic-вайпе удаляется вместе с базой (KiokioConfig.wipe).
 */
public final class KiokioConfig {

    private static final String FILE = "ghosttalk_config.json";

    public static JSONObject load(Context ctx) {
        try {
            File f = new File(ctx.getFilesDir(), FILE);
            if (f.exists()) {
                FileInputStream in = new FileInputStream(f);
                byte[] buf = new byte[(int) f.length()];
                int read = in.read(buf);
                in.close();
                if (read > 0) return new JSONObject(new String(buf, StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
        }
        return defaults();
    }

    public static void save(Context ctx, JSONObject cfg) {
        try {
            FileOutputStream out = new FileOutputStream(new File(ctx.getFilesDir(), FILE));
            out.write(cfg.toString(2).getBytes(StandardCharsets.UTF_8));
            out.close();
        } catch (Exception ignored) {
        }
    }

    public static void wipe(Context ctx) {
        new File(ctx.getFilesDir(), FILE).delete();
    }

    public static JSONObject defaults() {
        JSONObject cfg = new JSONObject();
        try {
            JSONObject theme = new JSONObject();
            theme.put("accent", "#FFA500");
            theme.put("background", "#0D0D0D");

            JSONObject terminal = new JSONObject();
            terminal.put("extraCommands", new org.json.JSONArray());

            JSONObject presence = new JSONObject();
            presence.put("hideOnline", false);
            presence.put("hideTyping", false);
            presence.put("hideRead", false);

            JSONObject wipe = new JSONObject();
            wipe.put("panicTrigger", "triple_tap_version");
            wipe.put("aggressive", false);

            cfg.put("theme", theme);
            cfg.put("terminal", terminal);
            cfg.put("presence", presence);
            cfg.put("wipe", wipe);
        } catch (Exception ignored) {
        }
        return cfg;
    }

    private KiokioConfig() {}
}
