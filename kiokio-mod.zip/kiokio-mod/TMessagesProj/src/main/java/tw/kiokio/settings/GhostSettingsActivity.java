package tw.kiokio.settings;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Kiokio — обычная настройка мода. */
public class GhostSettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);

        section(root, "KIOKIO \u00B7 НАСТРОЙКА МОДА");

        item(root, "Приватность", v -> {
            // TODO: тумблеры присутствия: онлайн / печатает / прочтения / сторис
        });
        item(root, "Сеть", v -> {
            // TODO: прокси-цепочка, kill-switch, панель маршрута /route
        });
        item(root, "Хранение", v -> {
            // TODO: SQLCipher-пароль, panic-вайп, режим пустышки
        });
        item(root, "Терминал", v -> {
            // TODO: тема, акцентный цвет, свои команды, конфиг
        });
        item(root, "Профили", v -> {
            // TODO: рабочий / публичный / чистый
        });

        section(root, "О ПРОЕКТЕ");
        item(root, "Исходный код", v ->
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://github.com/ТВОЙ_НИК/ТВОЙ_ФОРК"))));
        item(root, "Лицензия", v ->
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://github.com/DrKLO/Telegram/blob/master/LICENSE"))));

        section(root, "KIOKIO PRO");
        item(root, "Специальное меню", v ->
                startActivity(new Intent(this, KiokioProGateActivity.class)));

        root.addView(Disclaimer.view(this)); // дисклеймер всегда в самом низу
    }

    private void section(LinearLayout root, String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(48, 48, 48, 16);
        root.addView(tv);
    }

    private void item(LinearLayout root, String title, View.OnClickListener c) {
        TextView tv = new TextView(this);
        tv.setText("\u25B8 " + title);
        tv.setTextSize(17);
        tv.setPadding(48, 36, 48, 36);
        if (c != null) tv.setOnClickListener(c);
        root.addView(tv);
    }
}
