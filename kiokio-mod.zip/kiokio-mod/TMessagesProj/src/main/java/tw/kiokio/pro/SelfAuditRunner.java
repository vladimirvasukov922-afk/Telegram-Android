package tw.kiokio.pro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

/**
 * Конвейер самопроверки «Проверить меня».
 * Работает только по данным текущего аккаунта. Ничего не сохраняет.
 *
 * Точки вживления (отмечены TODO): в форке Telegram-Android данные берутся
 * штатными запросами через MessagesController / ConnectionsManager:
 *   - account.getPrivacy        — правила приватности номера/онлайна/био
 *   - users.getFullUser         — как профиль виден постороннему
 *   - account.getAuthorizations — список активных сессий
 *   - Have I Been Pwned (k-anonymity, передаётся только префикс хэша почты)
 *   - упоминания юзернейма: открываются готовые поисковые запросы в браузере
 */
public final class SelfAuditRunner {

    public interface Done { void out(String text); }

    public static void run(Activity activity, Done done) {
        StringBuilder sb = new StringBuilder();

        sb.append("\u25B8 ЧТО ВИДНО ИЗ TELEGRAM\n");
        sb.append("  \u00B7 номер: TODO TL_account.getPrivacy\n");
        sb.append("  \u00B7 онлайн: TODO TL_account.getPrivacy\n");
        sb.append("  \u00B7 био/аватар: TODO TL_users.getFullUser\n\n");

        sb.append("\u25B8 АКТИВНЫЕ СЕССИИ\n");
        sb.append("  \u00B7 TODO TL_account.getAuthorizations\n");
        sb.append("  \u00B7 неизвестная сессия \u2192 \u00ABзавершить\u00BB\n\n");

        sb.append("\u25B8 УТЕЧКИ ПО ПОЧТЕ\n");
        sb.append("  \u00B7 TODO: хэш почты \u2192 api.haveibeenpwned.com (k-anonymity)\n\n");

        sb.append("\u25B8 УПОМИНАНИЯ ЮЗЕРНЕЙМА\n");
        sb.append("  \u00B7 готовые поисковые запросы открываются в браузере\n\n");

        sb.append("[ ЧЕКЛИСТ ЗАЧИСТКИ ]\n");

        done.out(sb.toString());

        // Пример открытия поискового запроса по своему юзернейму:
        // Intent i = new Intent(Intent.ACTION_VIEW,
        //         Uri.parse("https://yandex.ru/search/?text=%22МОЙ_НИК%22"));
        // activity.startActivity(i);
    }

    private SelfAuditRunner() {}
}
