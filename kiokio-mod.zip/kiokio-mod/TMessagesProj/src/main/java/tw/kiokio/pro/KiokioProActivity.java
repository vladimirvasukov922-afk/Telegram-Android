package tw.kiokio.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

import tw.kiokio.settings.Disclaimer;

/**
 * Kiokio Pro — специальное меню.
 * Всё содержимое — только white hat и только над своим аккаунтом.
 */
public class KiokioProActivity extends Activity {

    /** Красная линия проекта: не реализуется ни в каком виде, никогда. */
    private static final List<String> BLOCKED = Arrays.asList(
            "определение чужого IP-адреса",
            "определение геолокации других людей",
            "анти-ревоки и вычисление нарушителей",
            "пробив по номеру, нику или аккаунту",
            "сбор данных через IP-грабберы и ссылки-ловушки",
            "брутфорс и обход защит",
            "юзерботы-рассылки и спам",
            "доступ к чужим данным любым способом"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);

        title(root, "KIOKIO PRO");
        subtitle(root, "специальное меню \u00B7 жёсткие функции контроля");

        item(root, "/audit   \u2014 аудит аккаунта и сессий", v -> {
            // TODO: account.getAuthorizations + account.getPrivacy
        });
        item(root, "/selfdox \u2014 «След»: ПРОВЕРИТЬ МЕНЯ", v ->
                startActivity(new Intent(this, SelfAuditActivity.class)));
        item(root, "/opsec   \u2014 чеклист гигиены аккаунта", null);
        item(root, "/explain \u2014 обучающие разборы уязвимостей", null);
        item(root, "/keys    \u2014 верификация ключей собеседников", null);
        item(root, "/route   \u2014 панель сети и маршрут прокси", null);
        item(root, "/redact  \u2014 шаги зачистки своих данных", null);

        TextView bl = new TextView(this);
        bl.setText("\u2014 ЗАБЛОКИРОВАНО НАВСЕГДА \u2014");
        bl.setPadding(48, 48, 48, 8);
        root.addView(bl);
        for (String b : BLOCKED) {
            TextView tv = new TextView(this);
            tv.setText("\u2717 " + b);
            tv.setTextSize(13);
            tv.setPadding(48, 8, 48, 8);
            root.addView(tv);
        }

        root.addView(Disclaimer.view(this));
    }

    private void title(LinearLayout root, String s) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(20);
        tv.setPadding(48, 48, 48, 8);
        root.addView(tv);
    }

    private void subtitle(LinearLayout root, String s) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(13);
        tv.setPadding(48, 0, 48, 24);
        root.addView(tv);
    }

    private void item(LinearLayout root, String s, View.OnClickListener c) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(15);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(48, 32, 48, 32);
        if (c != null) tv.setOnClickListener(c);
        root.addView(tv);
    }
}
