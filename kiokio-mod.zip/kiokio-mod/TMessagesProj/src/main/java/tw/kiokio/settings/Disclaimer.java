package tw.kiokio.settings;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.TextView;

/** Дисклеймер внизу каждого экрана мода. */
public final class Disclaimer {

    private static final String TEXT =
            "\u26A0 ВНИМАНИЕ\n" +
            "Функции этого раздела созданы для белых хакеров (white hat)\n" +
            "и учебных целей. Использовать их разрешено только на своих\n" +
            "устройствах, аккаунтах и сетях — либо с явного письменного\n" +
            "разрешения владельца проверяемой системы.\n" +
            "Создатель мода не несёт ответственности за то,\n" +
            "как вы используете эти функции.\n" +
            "Автор мода осуждает доксинг; функции сбора данных о других\n" +
            "людях в мод не включены и не будут включены.";

    public static TextView view(Activity activity) {
        TextView tv = new TextView(activity);
        SpannableString s = new SpannableString(TEXT);
        s.setSpan(new ForegroundColorSpan(0xFFFFA500), 0, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv.setText(s);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tv.setTextColor(Color.parseColor("#8A8A8A"));
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(64, 32, 64, 64);
        tv.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return tv;
    }

    private Disclaimer() {}
}
