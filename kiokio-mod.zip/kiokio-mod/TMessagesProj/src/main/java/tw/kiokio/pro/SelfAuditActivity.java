package tw.kiokio.pro;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import tw.kiokio.settings.Disclaimer;

/**
 * «След» — панель самопроверки.
 * Объект проверки всегда — текущий авторизованный аккаунт, подменить нельзя.
 * Отчёт живёт только в памяти экрана: закрыл — исчез. В БД не пишется.
 */
public class SelfAuditActivity extends Activity {

    private TextView report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);

        TextView head = new TextView(this);
        head.setText("KIOKIO PRO \u00B7 СЛЕД");
        head.setTextSize(20);
        head.setPadding(48, 48, 48, 8);
        root.addView(head);

        TextView note = new TextView(this);
        note.setText("Проверка идёт только по вашему текущему аккаунту.\nРезультаты нигде не сохраняются.");
        note.setTextSize(13);
        note.setPadding(48, 0, 48, 24);
        root.addView(note);

        Button run = new Button(this);
        run.setText("ПРОВЕРИТЬ МЕНЯ");
        run.setOnClickListener(v -> {
            report.setText("проверяю\u2026");
            SelfAuditRunner.run(this, text -> runOnUiThread(() -> report.setText(text)));
        });
        root.addView(run);

        report = new TextView(this);
        report.setTypeface(Typeface.MONOSPACE);
        report.setTextSize(13);
        report.setPadding(48, 24, 48, 24);
        root.addView(report);

        root.addView(Disclaimer.view(this));
    }
}
