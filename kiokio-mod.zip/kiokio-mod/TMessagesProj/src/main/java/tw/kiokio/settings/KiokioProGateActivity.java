package tw.kiokio.settings;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import tw.kiokio.core.ProCode;
import tw.kiokio.pro.KiokioProActivity;

/**
 * Вход в Kiokio Pro по коду.
 * Хэш — в ProCode.java. Факт входа нигде не логируется.
 * После 3 ошибок — пауза 30 секунд (защита от перебора).
 */
public class KiokioProGateActivity extends Activity {

    private int fails = 0;
    private long lockedUntil = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        setContentView(root);

        final EditText code = new EditText(this);
        code.setHint("Введите код");
        code.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        code.setTransformationMethod(PasswordTransformationMethod.getInstance());
        code.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(96, 0, 96, 24);
        root.addView(code, lp);

        Button ok = new Button(this);
        ok.setText("Разблокировать");
        ok.setOnClickListener(v -> {
            if (System.currentTimeMillis() < lockedUntil) return;
            if (ProCode.check(code.getText().toString())) {
                startActivity(new Intent(this, KiokioProActivity.class));
                finish();
            } else {
                fails++;
                Toast.makeText(this, "Неверный код", Toast.LENGTH_SHORT).show();
                if (fails >= 3) {
                    lockedUntil = System.currentTimeMillis() + 30_000L;
                    fails = 0;
                    Toast.makeText(this, "Пауза 30 секунд", Toast.LENGTH_LONG).show();
                    new Handler(Looper.getMainLooper()).postDelayed(
                            () -> Toast.makeText(this, "Можно снова вводить код", Toast.LENGTH_SHORT),
                            30_000L);
                }
            }
        });
        root.addView(ok);

        root.addView(Disclaimer.view(this));
    }
}
